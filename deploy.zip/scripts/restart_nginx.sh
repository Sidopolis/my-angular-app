#!/bin/bash
systemctl restart nginx